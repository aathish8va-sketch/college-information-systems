from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
from werkzeug.utils import secure_filename
import os
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from config import Config
from models import db, User, Student, Attendance, Result, Homework, Timetable, CycleTest, Competition, Revision, Practical, Announcement
from datetime import datetime, date
from sqlalchemy import func, case

app = Flask(__name__)
app.config.from_object(Config)

# Initialize extensions
db.init_app(app)
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'home'


@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))


def _homework_assignment_key(subject, title, due_date):
    """Build a normalized key for homework de-duplication."""
    due_key = due_date.isoformat() if due_date else ''
    return ((subject or '').strip().lower(), (title or '').strip().lower(), due_key)


def auto_assign_semester_homework(student, commit=True):
    """
    Auto-backfill homework for a student from existing assignments in the same semester.
    This keeps newly added or previously empty students in sync with class homework.
    """
    if not student or student.semester is None:
        return 0

    existing_homework = Homework.query.filter_by(student_id=student.id).all()
    existing_keys = {
        _homework_assignment_key(row.subject, row.title, row.due_date)
        for row in existing_homework
    }

    semester_homework = db.session.query(Homework) \
        .join(Student, Homework.student_id == Student.id) \
        .filter(
            Student.semester == student.semester,
            Homework.student_id != student.id,
            Homework.status == 'Pending'
        ) \
        .order_by(Homework.created_at.desc()) \
        .all()

    created_count = 0
    for source_hw in semester_homework:
        key = _homework_assignment_key(source_hw.subject, source_hw.title, source_hw.due_date)
        if key in existing_keys:
            continue

        cloned_hw = Homework(
            student_id=student.id,
            subject=source_hw.subject,
            title=source_hw.title,
            description=source_hw.description,
            due_date=source_hw.due_date,
            status='Pending'
        )
        db.session.add(cloned_hw)
        existing_keys.add(key)
        created_count += 1

    if created_count and commit:
        db.session.commit()

    return created_count


# ---------------------------------
# HOME → LOGIN PAGE
# ---------------------------------
@app.route('/')
def home():
    if current_user.is_authenticated:
        if current_user.role == 'admin':
            return redirect(url_for('admin_dashboard'))
        return redirect(url_for('dashboard'))
    return render_template('login.html')

# ---------------------------------
# LOGIN CHECK
# ---------------------------------
@app.route('/login', methods=['POST'])
def login():
    userid = request.form.get('userid')
    password = request.form.get('password')

    user = User.query.filter_by(username=userid).first()
    
    if user and user.check_password(password):
        login_user(user)
        flash('✅ Login successful!', 'success')
        
        if user.role == 'admin':
            return redirect(url_for('admin_dashboard'))
        return redirect(url_for('dashboard'))
    else:
        flash('❌ Invalid ID or Password', 'error')
        return render_template("login.html", error="❌ Invalid ID or Password")


# ---------------------------------
# LOGOUT
# ---------------------------------
@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('👋 Logged out successfully', 'info')
    return redirect(url_for('home'))


# ---------------------------------
# DASHBOARD PAGE
# ---------------------------------
@app.route('/dashboard')
@login_required
def dashboard():
    if current_user.role == 'admin':
        return redirect(url_for('admin_dashboard'))

    student = current_user.student
    if not student:
        flash('Student profile not linked to this account.', 'error')
        return redirect(url_for('logout'))

    try:
        auto_assign_semester_homework(student)
    except Exception:
        db.session.rollback()
    
    # Calculate attendance percentage
    total_attendance = Attendance.query.filter_by(student_id=student.id).count()
    present_count = Attendance.query.filter_by(student_id=student.id, status='Present').count()
    attendance_pct = round((present_count / total_attendance * 100), 1) if total_attendance > 0 else 0
    
    # Count pending homework
    pending_homework = Homework.query.filter_by(student_id=student.id, status='Pending').count()

    # Show assigned homework directly on dashboard (pending first)
    homework_priority = case((Homework.status == 'Pending', 0), else_=1)
    assigned_homework = Homework.query.filter_by(student_id=student.id) \
        .order_by(homework_priority.asc(), Homework.due_date.asc(), Homework.created_at.desc()) \
        .limit(6) \
        .all()
    
    # Fetch recent announcements (limit 3)
    announcements = Announcement.query.order_by(Announcement.date_posted.desc()).limit(3).all()
    
    return render_template('dashboard.html', 
                         student=student, 
                         attendance_pct=attendance_pct,
                         pending_homework=pending_homework,
                         announcements=announcements,
                         assigned_homework=assigned_homework)


# ---------------------------------
# TIMETABLE PAGE
# ---------------------------------
@app.route('/timetable')
@login_required
def timetable():
    student = current_user.student
    timetable_data = Timetable.query.filter_by(semester=student.semester).order_by(Timetable.day, Timetable.period).all()
    
    # Organize by day
    days_order = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]
    timetable_by_day = {day: [] for day in days_order}
    
    for entry in timetable_data:
        if entry.day in timetable_by_day:
            timetable_by_day[entry.day].append(entry)
    
    return render_template('timetable.html', timetable=timetable_by_day, days=days_order)


# ---------------------------------
# HOMEWORK PAGE
# ---------------------------------
@app.route('/homework')
@login_required
def homework():
    student = current_user.student
    try:
        auto_assign_semester_homework(student)
    except Exception:
        db.session.rollback()
    homework_list = Homework.query.filter_by(student_id=student.id).order_by(Homework.due_date).all()
    return render_template('homework.html', homework_list=homework_list)


# ---------------------------------
# MARK HOMEWORK COMPLETE
# ---------------------------------
@app.route('/homework/complete/<int:hw_id>', methods=['POST'])
@login_required
def complete_homework(hw_id):
    homework = Homework.query.get_or_404(hw_id)
    if homework.student_id == current_user.student.id:
        homework.status = 'Completed'
        homework.submission_date = datetime.utcnow()
        db.session.commit()
        flash('✅ Homework marked as completed!', 'success')
    return redirect(url_for('homework'))


# ---------------------------------
# ATTENDANCE PAGE
# ---------------------------------
@app.route('/attendance')
@login_required
def attendance():
    student = current_user.student
    
    # Get all attendance records for the student
    all_records = Attendance.query.filter_by(student_id=student.id).all()
    
    # Group by subject
    subject_dict = {}
    for record in all_records:
        if record.subject not in subject_dict:
            subject_dict[record.subject] = {'present': 0, 'absent': 0, 'total': 0}
        
        subject_dict[record.subject]['total'] += 1
        if record.status == 'Present':
            subject_dict[record.subject]['present'] += 1
        elif record.status == 'Absent':
            subject_dict[record.subject]['absent'] += 1
    
    # Calculate percentages
    attendance_data = []
    for subject, counts in subject_dict.items():
        pct = round((counts['present'] /  counts['total'] * 100), 1) if counts['total'] > 0 else 0
        attendance_data.append({
            'subject': subject,
            'percentage': pct,
            'present': counts['present'],
            'absent': counts['absent'],
            'total': counts['total']
        })
    
    return render_template('attendance.html', attendance_data=attendance_data)


# ---------------------------------
# REVISION TEST PAGE
# ---------------------------------
@app.route('/revision')
@login_required
def revision():
    student = current_user.student
    revisions = Revision.query.filter_by(student_id=student.id).order_by(Revision.subject, Revision.test_number).all()
    
    # Process data for view
    # Group by subject? or just list? The template seemed to show table by subject
    # Let's organize by subject for easier display if needed, or pass list
    
    return render_template('revision.html', revisions=revisions)


# ---------------------------------
# RESULT PAGE (Pass/Fail Logic)
# ---------------------------------
@app.route('/result', methods=['GET', 'POST'])
@login_required
def result():
    if request.method == "POST":
        roll = request.form.get("roll")
        
        student = Student.query.filter_by(roll_number=roll).first()
        
        if not student:
            return render_template("result.html", error="❌ Roll number not found!")
        
        # Get results for the student
        results = Result.query.filter_by(student_id=student.id).all()
        
        if not results:
            return render_template("result.html", error="❌ No results found for this student!")
        
        # Organize results by subject
        subjects = {}
        for res in results:
            subjects[res.subject] = res.marks
        
        # Collect arrear subjects (<35)
        arrears = [sub for sub, mark in subjects.items() if mark < 35]
        
        # Final result
        if len(arrears) == 0:
            status = "ALL CLEAR 🎉"
        else:
            status = "ARREAR ❌ (" + ", ".join(arrears) + ")"
        
        # Calculate total and percentage
        total_marks = sum(subjects.values())
        max_possible = len(subjects) * 100
        percentage = round((total_marks / max_possible * 100), 2) if max_possible > 0 else 0
        
        return render_template(
            "result.html",
            roll=roll,
            name=student.name,
            subjects=subjects,
            status=status,
            total=total_marks,
            percentage=percentage
        )
    
    return render_template("result.html")


# ---------------------------------
# CYCLE TEST PAGE
# ---------------------------------
@app.route('/cycletest')
@login_required
def cycletest():
    student = current_user.student
    cycletests = CycleTest.query.filter_by(student_id=student.id).order_by(CycleTest.cycle_number, CycleTest.subject).all()
    
    # Organize by cycle and subject
    cycles_data = {}
    for test in cycletests:
        cycle = f"Cycle {test.cycle_number}"
        if cycle not in cycles_data:
            cycles_data[cycle] = []
        cycles_data[cycle].append(test)
    
    return render_template('cycletest.html', cycles_data=cycles_data)


# ---------------------------------
# PRACTICAL PAGE
# ---------------------------------
@app.route('/practical')
@login_required
def practical():
    student = current_user.student
    practicals = Practical.query.filter_by(student_id=student.id).all()
    return render_template('practical.html', practicals=practicals)


# ---------------------------------
# COMPETITION PAGE
# ---------------------------------
@app.route('/competition')
@login_required
def competition():
    # Get all competitions
    all_competitions = Competition.query.order_by(Competition.event_date.desc()).all()
    
    # Get student's competitions
    student_competitions = Competition.query.filter_by(student_id=current_user.student.id).all()
    
    return render_template('competition.html', 
                         all_competitions=all_competitions,
                         student_competitions=student_competitions)


# ---------------------------------
# STUDENT PERFORMANCE PAGE
# ---------------------------------
@app.route('/performance')
@login_required
def performance():
    student = current_user.student
    
    # ====== ATTENDANCE METRICS ======
    total_attendance = Attendance.query.filter_by(student_id=student.id).count()
    present_count = Attendance.query.filter_by(student_id=student.id, status='Present').count()
    attendance_pct = round((present_count / total_attendance * 100), 1) if total_attendance > 0 else 0
    
    # ====== EXAM RESULTS METRICS ======
    results = Result.query.filter_by(student_id=student.id).all()
    total_subjects = len(results)
    exam_avg = 0
    subjects_passed = 0
    subjects_failed = 0
    subject_results = []
    
    if results:
        total_marks = sum(r.marks for r in results)
        max_possible = sum(r.max_marks for r in results)
        exam_avg = round((total_marks / max_possible * 100), 1) if max_possible > 0 else 0
        
        for r in results:
            pct = round((r.marks / r.max_marks * 100), 1) if r.max_marks > 0 else 0
            passed = r.marks >= 35
            if passed:
                subjects_passed += 1
            else:
                subjects_failed += 1
            subject_results.append({
                'subject': r.subject,
                'marks': r.marks,
                'max_marks': r.max_marks,
                'percentage': pct,
                'passed': passed
            })
    
    # ====== CYCLE TEST METRICS ======
    cycletests = CycleTest.query.filter_by(student_id=student.id).all()
    cycle_avg = 0
    cycle_data = {}
    
    if cycletests:
        total_ct_marks = sum(ct.marks for ct in cycletests)
        total_ct_max = sum(ct.max_marks for ct in cycletests)
        cycle_avg = round((total_ct_marks / total_ct_max * 100), 1) if total_ct_max > 0 else 0
        
        # Group by cycle
        for ct in cycletests:
            cycle_key = f"Cycle {ct.cycle_number}"
            if cycle_key not in cycle_data:
                cycle_data[cycle_key] = {'marks': 0, 'max': 0, 'subjects': []}
            cycle_data[cycle_key]['marks'] += ct.marks
            cycle_data[cycle_key]['max'] += ct.max_marks
            cycle_data[cycle_key]['subjects'].append({
                'subject': ct.subject,
                'marks': ct.marks,
                'max_marks': ct.max_marks,
                'percentage': round((ct.marks / ct.max_marks * 100), 1) if ct.max_marks > 0 else 0
            })
        
        # Calculate cycle averages
        for cycle_key in cycle_data:
            c = cycle_data[cycle_key]
            c['average'] = round((c['marks'] / c['max'] * 100), 1) if c['max'] > 0 else 0
    
    # ====== HOMEWORK METRICS ======
    all_homework = Homework.query.filter_by(student_id=student.id).all()
    total_homework = len(all_homework)
    completed_homework = len([h for h in all_homework if h.status == 'Completed'])
    pending_homework = total_homework - completed_homework
    homework_rate = round((completed_homework / total_homework * 100), 1) if total_homework > 0 else 0
    
    # ====== OVERALL PERFORMANCE SCORE ======
    # Weighted average: Attendance 20%, Exams 40%, Cycle Tests 25%, Homework 15%
    overall_score = round(
        (attendance_pct * 0.20) + 
        (exam_avg * 0.40) + 
        (cycle_avg * 0.25) + 
        (homework_rate * 0.15)
    , 1)
    
    # Determine performance grade
    if overall_score >= 90:
        grade = 'A+'
        grade_color = '#10b981'
    elif overall_score >= 80:
        grade = 'A'
        grade_color = '#22c55e'
    elif overall_score >= 70:
        grade = 'B+'
        grade_color = '#84cc16'
    elif overall_score >= 60:
        grade = 'B'
        grade_color = '#eab308'
    elif overall_score >= 50:
        grade = 'C'
        grade_color = '#f59e0b'
    elif overall_score >= 40:
        grade = 'D'
        grade_color = '#f97316'
    else:
        grade = 'F'
        grade_color = '#ef4444'
    
    return render_template('performance.html',
        student=student,
        attendance_pct=attendance_pct,
        exam_avg=exam_avg,
        cycle_avg=cycle_avg,
        homework_rate=homework_rate,
        overall_score=overall_score,
        grade=grade,
        grade_color=grade_color,
        total_subjects=total_subjects,
        subjects_passed=subjects_passed,
        subjects_failed=subjects_failed,
        subject_results=subject_results,
        cycle_data=cycle_data,
        completed_homework=completed_homework,
        pending_homework=pending_homework
    )


# ---------------------------------
# PROFILE PAGE
# ---------------------------------
@app.route('/profile')
@login_required
def profile():
    student = current_user.student
    return render_template('profile.html', student=student)


# ---------------------------------
# ERROR HANDLERS
# ---------------------------------
@app.errorhandler(404)
def not_found(error):
    return render_template('404.html'), 404


@app.errorhandler(500)
def internal_error(error):
    db.session.rollback()
    return render_template('500.html'), 500


# ---------------------------------
# PROFILE PHOTO UPLOAD
# ---------------------------------
@app.route('/upload_profile_pic', methods=['POST'])
@login_required
def upload_profile_pic():
    if 'profile_pic' not in request.files:
        flash('No file part', 'error')
        return redirect(url_for('profile'))
    
    file = request.files['profile_pic']
    
    if file.filename == '':
        flash('No selected file', 'error')
        return redirect(url_for('profile'))
        
    if file:
        filename = secure_filename(f"user_{current_user.student.id}_{int(datetime.now().timestamp())}_{file.filename}")
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        
        # Ensure upload directory exists
        os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
        
        file.save(file_path)
        
        # Update database
        current_user.student.profile_picture = filename
        db.session.commit()
        
        flash('✅ Profile picture updated!', 'success')
        return redirect(url_for('profile'))

    return redirect(url_for('profile'))


@app.route('/remove_profile_pic', methods=['POST'])
@login_required
def remove_profile_pic():
    current_user.student.profile_picture = 'default.png'
    db.session.commit()
    flash('✅ Profile picture removed!', 'success')
    return redirect(url_for('profile'))



# ---------------------------------
# ADMIN ROUTES
# ---------------------------------
@app.route('/admin/dashboard')
@login_required
def admin_dashboard():
    if current_user.role != 'admin':
        flash('⛔ Access denied! Admin only.', 'error')
        return redirect(url_for('dashboard'))
        
    # Gather metrics
    total_students = Student.query.count()
    total_attendance_records = Attendance.query.count()
    
    # Calculate overall attendance percentage
    present_count = Attendance.query.filter_by(status='Present').count()
    overall_attendance = round((present_count / total_attendance_records * 100), 1) if total_attendance_records > 0 else 0
    total_timetable_entries = Timetable.query.count()
    
    return render_template('admin_dashboard.html', 
                         total_students=total_students,
                         overall_attendance=overall_attendance,
                         total_timetable_entries=total_timetable_entries)


@app.route('/admin/students')
@login_required
def admin_students():
    if current_user.role != 'admin':
        return redirect(url_for('dashboard'))
        
    students = Student.query.order_by(Student.roll_number).all()
    return render_template('admin_students.html', students=students)


@app.route('/admin/student/add', methods=['POST'])
@login_required
def admin_add_student():
    if current_user.role != 'admin':
        return jsonify({'success': False, 'message': 'Unauthorized'}), 403
        
    name = request.form.get('name')
    roll_number = request.form.get('roll_number')
    email = request.form.get('email')
    phone = request.form.get('phone')
    department = request.form.get('department')
    semester = request.form.get('semester')
    username = request.form.get('username')
    password = request.form.get('password')
    
    # Validation
    if not all([name, roll_number, email, department, semester, username, password]):
        flash('Missing required fields!', 'error')
        return redirect(url_for('admin_students'))
        
    if Student.query.filter_by(roll_number=roll_number).first():
        flash('Roll number already exists!', 'error')
        return redirect(url_for('admin_students'))
        
    if User.query.filter_by(username=username).first():
        flash('User account with this username already exists!', 'error')
        return redirect(url_for('admin_students'))
        
    try:
        new_student = Student(
            name=name,
            roll_number=roll_number,
            email=email,
            phone=phone,
            department=department,
            semester=int(semester)
        )
        db.session.add(new_student)
        db.session.flush() # Get student ID
        
        # Create corresponding user account with custom password
        new_user = User(
            username=username,
            role='student',
            student_id=new_student.id
        )
        new_user.set_password(password)
        db.session.add(new_user)
        
        db.session.commit()

        copied_homework = auto_assign_semester_homework(new_student)
        if copied_homework:
            flash(
                f'✅ Student added successfully! Login ID is "{username}". '
                f'Copied {copied_homework} semester homework task(s).',
                'success'
            )
        else:
            flash(f'✅ Student added successfully! Login ID is "{username}"', 'success')
        
    except Exception as e:
        db.session.rollback()
        flash(f'❌ Error adding student: {str(e)}', 'error')
        
    return redirect(url_for('admin_students'))


@app.route('/admin/student/<int:student_id>/edit', methods=['POST'])
@login_required
def admin_edit_student(student_id):
    if current_user.role != 'admin':
        return jsonify({'success': False, 'message': 'Unauthorized'}), 403
        
    student = Student.query.get_or_404(student_id)
    
    name = request.form.get('name')
    roll_number = request.form.get('roll_number')
    email = request.form.get('email')
    phone = request.form.get('phone')
    department = request.form.get('department')
    semester = request.form.get('semester')
    username = request.form.get('username')
    password = request.form.get('password')
    
    # Validation
    if not all([name, roll_number, email, department, semester, username]):
        flash('Missing required fields!', 'error')
        return redirect(url_for('admin_students'))
        
    # Check if new roll number conflicts with another student
    conflict = Student.query.filter(Student.roll_number == roll_number, Student.id != student_id).first()
    if conflict:
        flash('Roll number already in use by another student!', 'error')
        return redirect(url_for('admin_students'))
        
    # Check if new username conflicts with another user
    username_conflict = User.query.filter(User.username == username, User.student_id != student_id).first()
    if username_conflict:
        flash('Username already in use by another account!', 'error')
        return redirect(url_for('admin_students'))
        
    try:
        student.name = name
        student.email = email
        student.phone = phone
        student.department = department
        student.semester = int(semester)
        student.roll_number = roll_number
        
        if student.user:
            student.user.username = username
            if password:  # if a new password is provided, update it
                student.user.set_password(password)
                
        db.session.commit()
        auto_assign_semester_homework(student)
        flash('✅ Student details updated successfully!', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'❌ Error updating student: {str(e)}', 'error')
        
    return redirect(url_for('admin_students'))


@app.route('/admin/student/<int:student_id>/delete', methods=['POST'])
@login_required
def admin_delete_student(student_id):
    if current_user.role != 'admin':
        return jsonify({'success': False, 'message': 'Unauthorized'}), 403
        
    student = Student.query.get_or_404(student_id)
    
    try:
        db.session.delete(student)
        db.session.commit()
        flash('✅ Student deleted successfully!', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'❌ Error deleting student: {str(e)}', 'error')
        
    return redirect(url_for('admin_students'))


@app.route('/admin/student/<int:student_id>')
@login_required
def admin_student_detail(student_id):
    if current_user.role != 'admin':
        return redirect(url_for('dashboard'))
        
    student = Student.query.get_or_404(student_id)
    
    # Calculate some basic metrics for the view
    total_attendance = Attendance.query.filter_by(student_id=student.id).count()
    present_count = Attendance.query.filter_by(student_id=student.id, status='Present').count()
    attendance_pct = round((present_count / total_attendance * 100), 1) if total_attendance > 0 else 0
    
    pending_homework = Homework.query.filter_by(student_id=student.id, status='Pending').count()
    
    return render_template('admin_student_detail.html', 
                         student=student,
                         attendance_pct=attendance_pct,
                         pending_homework=pending_homework)


@app.route('/admin/upload', methods=['GET', 'POST'])
@login_required
def admin_upload():
    if current_user.role != 'admin':
        return redirect(url_for('dashboard'))
        
    if request.method == 'POST':
        if 'file' not in request.files:
            flash('No file part', 'error')
            return redirect(request.url)
            
        file = request.files['file']
        if file.filename == '':
            flash('No selected file', 'error')
            return redirect(request.url)
            
        if file:
            upload_type = request.form.get('upload_type', 'general')
            filename = secure_filename(f"{upload_type}_{int(datetime.now().timestamp())}_{file.filename}")
            
            # Subfolder based on type
            subfolder = 'others'
            if upload_type == 'attendance':
                subfolder = 'attendance_sheets'
            elif upload_type == 'result':
                subfolder = 'exam_results'
            elif upload_type == 'cycletest':
                subfolder = 'cycletest_marks'
            elif upload_type == 'revision':
                subfolder = 'revision_materials'
            elif upload_type == 'practical':
                subfolder = 'practical_records'
            elif upload_type == 'overall':
                subfolder = 'general_uploads'
                
            upload_path = os.path.join(app.config['UPLOAD_FOLDER'], 'admin_uploads', subfolder)
            os.makedirs(upload_path, exist_ok=True)
            
            file.save(os.path.join(upload_path, filename))
            
            # Format friendly name
            type_name = upload_type.replace('_', ' ').title()
            flash(f'✅ {type_name} file uploaded successfully!', 'success')
            
    return render_template('admin_upload.html')


@app.route('/admin/timetable', methods=['GET', 'POST'])
@login_required
def admin_timetable():
    if current_user.role != 'admin':
        return redirect(url_for('dashboard'))

    days_order = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]

    if request.method == 'POST':
        entry_id = request.form.get('entry_id')
        day = (request.form.get('day') or '').strip()
        period = request.form.get('period')
        subject = (request.form.get('subject') or '').strip()
        teacher = (request.form.get('teacher') or '').strip()
        room = (request.form.get('room') or '').strip()
        semester = request.form.get('semester')
        start_time_str = request.form.get('start_time')
        end_time_str = request.form.get('end_time')

        entry_id_int = None
        if entry_id:
            try:
                entry_id_int = int(entry_id)
            except ValueError:
                flash('Invalid timetable entry id.', 'error')
                return redirect(url_for('admin_timetable'))

        if not all([day, period, subject, semester]):
            flash('Day, period, subject, and semester are required.', 'error')
            return redirect(url_for('admin_timetable', edit_id=entry_id_int, semester=semester or None))

        if day not in days_order:
            flash('Invalid day selected.', 'error')
            return redirect(url_for('admin_timetable', edit_id=entry_id_int, semester=semester or None))

        try:
            period_val = int(period)
            semester_val = int(semester)
            if period_val < 1:
                raise ValueError
        except ValueError:
            flash('Period and semester must be valid positive numbers.', 'error')
            return redirect(url_for('admin_timetable', edit_id=entry_id_int, semester=semester or None))

        try:
            start_time_obj = datetime.strptime(start_time_str, '%H:%M').time() if start_time_str else None
            end_time_obj = datetime.strptime(end_time_str, '%H:%M').time() if end_time_str else None
        except ValueError:
            flash('Invalid time value. Please use HH:MM format.', 'error')
            return redirect(url_for('admin_timetable', edit_id=entry_id_int, semester=semester_val))

        conflict_query = Timetable.query.filter_by(
            semester=semester_val,
            day=day,
            period=period_val
        )
        if entry_id_int:
            conflict_query = conflict_query.filter(Timetable.id != entry_id_int)

        if conflict_query.first():
            flash('A timetable entry already exists for that semester, day, and period.', 'error')
            return redirect(url_for('admin_timetable', edit_id=entry_id_int, semester=semester_val))

        try:
            if entry_id_int:
                entry = Timetable.query.get_or_404(entry_id_int)
                success_message = 'Timetable entry updated successfully.'
            else:
                entry = Timetable()
                db.session.add(entry)
                success_message = 'Timetable entry added successfully.'

            entry.day = day
            entry.period = period_val
            entry.subject = subject
            entry.teacher = teacher or None
            entry.room = room or None
            entry.start_time = start_time_obj
            entry.end_time = end_time_obj
            entry.semester = semester_val

            db.session.commit()
            flash(success_message, 'success')
        except Exception as e:
            db.session.rollback()
            flash(f'Error saving timetable entry: {str(e)}', 'error')

        return redirect(url_for('admin_timetable', semester=semester_val))

    day_sort = case(
        (Timetable.day == 'Monday', 1),
        (Timetable.day == 'Tuesday', 2),
        (Timetable.day == 'Wednesday', 3),
        (Timetable.day == 'Thursday', 4),
        (Timetable.day == 'Friday', 5),
        (Timetable.day == 'Saturday', 6),
        else_=7
    )

    semester_filter = request.args.get('semester', type=int)
    edit_id = request.args.get('edit_id', type=int)

    timetable_query = Timetable.query
    if semester_filter:
        timetable_query = timetable_query.filter_by(semester=semester_filter)

    timetable_entries = timetable_query.order_by(
        Timetable.semester.asc(),
        day_sort.asc(),
        Timetable.period.asc()
    ).all()

    edit_entry = Timetable.query.get(edit_id) if edit_id else None
    semester_rows = db.session.query(Student.semester) \
        .filter(Student.semester.isnot(None)) \
        .distinct() \
        .order_by(Student.semester.asc()) \
        .all()
    semester_options = [row[0] for row in semester_rows] or [1, 2, 3, 4, 5, 6, 7, 8]

    return render_template(
        'admin_timetable.html',
        timetable_entries=timetable_entries,
        edit_entry=edit_entry,
        semester_filter=semester_filter,
        semester_options=semester_options,
        days_order=days_order
    )


@app.route('/admin/timetable/delete/<int:entry_id>', methods=['POST'])
@login_required
def admin_delete_timetable(entry_id):
    if current_user.role != 'admin':
        return redirect(url_for('dashboard'))

    entry = Timetable.query.get_or_404(entry_id)
    semester = entry.semester

    try:
        db.session.delete(entry)
        db.session.commit()
        flash('Timetable entry deleted successfully.', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error deleting timetable entry: {str(e)}', 'error')

    return redirect(url_for('admin_timetable', semester=semester))


@app.route('/admin/manual/homework', methods=['GET', 'POST'])
@login_required
def admin_manual_homework():
    if current_user.role != 'admin':
        return redirect(url_for('dashboard'))

    students = Student.query.order_by(Student.roll_number).all()
    semester_rows = db.session.query(Student.semester) \
        .filter(Student.semester.isnot(None)) \
        .distinct() \
        .order_by(Student.semester.asc()) \
        .all()
    semester_options = [row[0] for row in semester_rows]

    if request.method == 'POST':
        subject = (request.form.get('subject') or '').strip()
        title = (request.form.get('title') or '').strip()
        description = (request.form.get('description') or '').strip()
        due_date_str = request.form.get('due_date')
        target_type = request.form.get('target_type', 'semester')
        semester = request.form.get('semester')
        student_id = request.form.get('student_id')

        if not subject or not title:
            flash('Subject and title are required.', 'error')
            return redirect(url_for('admin_manual_homework'))

        due_date_obj = None
        if due_date_str:
            try:
                due_date_obj = datetime.strptime(due_date_str, '%Y-%m-%d').date()
            except ValueError:
                flash('Invalid due date format.', 'error')
                return redirect(url_for('admin_manual_homework'))

        target_students = []
        if target_type == 'all':
            target_students = students
        elif target_type == 'semester':
            try:
                semester_val = int(semester)
            except (TypeError, ValueError):
                flash('Select a valid semester.', 'error')
                return redirect(url_for('admin_manual_homework'))
            target_students = [s for s in students if s.semester == semester_val]
        elif target_type == 'student':
            try:
                student_id_val = int(student_id)
            except (TypeError, ValueError):
                flash('Select a valid student.', 'error')
                return redirect(url_for('admin_manual_homework'))
            selected_student = Student.query.get(student_id_val)
            if selected_student:
                target_students = [selected_student]
        else:
            flash('Invalid assignment target.', 'error')
            return redirect(url_for('admin_manual_homework'))

        if not target_students:
            flash('No target students found for assignment.', 'error')
            return redirect(url_for('admin_manual_homework'))

        created_count = 0
        updated_count = 0
        try:
            for student in target_students:
                existing = Homework.query.filter_by(
                    student_id=student.id,
                    subject=subject,
                    title=title,
                    status='Pending'
                ).first()

                if existing:
                    existing.description = description or existing.description
                    existing.due_date = due_date_obj
                    updated_count += 1
                else:
                    hw = Homework(
                        student_id=student.id,
                        subject=subject,
                        title=title,
                        description=description or None,
                        due_date=due_date_obj,
                        status='Pending'
                    )
                    db.session.add(hw)
                    created_count += 1

            db.session.commit()
            flash(
                f'Homework assigned successfully. Created: {created_count}, Updated: {updated_count}.',
                'success'
            )
        except Exception as e:
            db.session.rollback()
            flash(f'Error while assigning homework: {str(e)}', 'error')

        return redirect(url_for('admin_manual_homework'))

    recent_homework = db.session.query(Homework, Student) \
        .join(Student, Homework.student_id == Student.id) \
        .order_by(Homework.created_at.desc()) \
        .limit(30) \
        .all()

    return render_template(
        'admin_manual_homework.html',
        students=students,
        semester_options=semester_options,
        recent_homework=recent_homework
    )


@app.route('/admin/manual/attendance', methods=['GET', 'POST'])
@login_required
def admin_manual_attendance():
    if current_user.role != 'admin':
        return redirect(url_for('dashboard'))
    
    if request.method == 'POST':
        date_str = request.form.get('date')
        subject = request.form.get('subject')
        
        if not date_str or not subject:
            flash('Date and Subject are required!', 'error')
            return redirect(url_for('admin_manual_attendance'))
            
        try:
            date_obj = datetime.strptime(date_str, '%Y-%m-%d').date()
            
            # Process each student's attendance
            students = Student.query.all()
            count = 0
            
            for student in students:
                status_key = f"status_{student.id}"
                status = request.form.get(status_key)
                
                if status:
                    # Check if record exists to avoid duplicates (optional, here we just add new)
                    # Ideally, check if attendance for this student+date+subject exists
                    existing = Attendance.query.filter_by(
                        student_id=student.id,
                        date=date_obj,
                        subject=subject
                    ).first()
                    
                    if existing:
                        existing.status = status
                    else:
                        new_attendance = Attendance(
                            student_id=student.id,
                            date=date_obj,
                            subject=subject,
                            status=status
                        )
                        db.session.add(new_attendance)
                    count += 1
            
            db.session.commit()
            flash(f'✅ Attendance marked for {count} students successfully!', 'success')
            return redirect(url_for('admin_upload'))
            
        except ValueError:
            flash('Invalid date format!', 'error')
            return redirect(url_for('admin_manual_attendance'))
    
    # GET request
    students = Student.query.order_by(Student.roll_number).all()
    return render_template('admin_manual_attendance.html', students=students)


@app.route('/admin/manual/result', methods=['GET', 'POST'])
@login_required
def admin_manual_result():
    if current_user.role != 'admin':
        return redirect(url_for('dashboard'))
    
    if request.method == 'POST':
        subject = request.form.get('subject')
        exam_type = request.form.get('exam_type')
        max_marks = request.form.get('max_marks')
        semester = request.form.get('semester')
        
        if not subject or not exam_type:
            flash('Subject and Exam Type are required!', 'error')
            return redirect(url_for('admin_manual_result'))
            
        students = Student.query.all()
        count = 0
        
        for student in students:
            marks_key = f"marks_{student.id}"
            marks = request.form.get(marks_key)
            
            if marks:
                if marks == "": continue # Skip empty inputs
                
                # Check for existing result (simple duplicates check)
                existing = Result.query.filter_by(
                    student_id=student.id,
                    subject=subject,
                    exam_type=exam_type,
                    semester=semester
                ).first()
                
                if existing:
                    existing.marks = int(marks)
                    existing.max_marks = int(max_marks)
                else:
                    new_result = Result(
                        student_id=student.id,
                        subject=subject,
                        marks=int(marks),
                        max_marks=int(max_marks),
                        exam_type=exam_type,
                        semester=int(semester),
                        exam_date=datetime.utcnow().date() # Default to today
                    )
                    db.session.add(new_result)
                count += 1
        
        db.session.commit()
        flash(f'✅ Results entered for {count} students successfully!', 'success')
        return redirect(url_for('admin_upload'))

    students = Student.query.order_by(Student.roll_number).all()
    return render_template('admin_manual_result.html', students=students)


@app.route('/admin/manual/cycletest', methods=['GET', 'POST'])
@login_required
def admin_manual_cycletest():
    if current_user.role != 'admin':
        return redirect(url_for('dashboard'))
    
    if request.method == 'POST':
        subject = request.form.get('subject')
        cycle_number = request.form.get('cycle_number')
        max_marks = request.form.get('max_marks')
        test_date_str = request.form.get('test_date')
        
        if not subject or not cycle_number:
            flash('Subject and Cycle Number are required!', 'error')
            return redirect(url_for('admin_manual_cycletest'))
            
        try:
            test_date = datetime.strptime(test_date_str, '%Y-%m-%d').date() if test_date_str else datetime.utcnow().date()
            
            students = Student.query.all()
            count = 0
            
            for student in students:
                marks_key = f"marks_{student.id}"
                marks = request.form.get(marks_key)
                
                if marks:
                    if marks == "": continue
                    
                    existing = CycleTest.query.filter_by(
                        student_id=student.id,
                        subject=subject,
                        cycle_number=int(cycle_number)
                    ).first()
                    
                    if existing:
                        existing.marks = int(marks)
                        existing.max_marks = int(max_marks)
                        existing.test_date = test_date
                    else:
                        new_test = CycleTest(
                            student_id=student.id,
                            subject=subject,
                            cycle_number=int(cycle_number),
                            marks=int(marks),
                            max_marks=int(max_marks),
                            test_date=test_date
                        )
                        db.session.add(new_test)
                    count += 1
            
            db.session.commit()
            flash(f'✅ Cycle Test marks entered for {count} students successfully!', 'success')
            return redirect(url_for('admin_upload'))
            
        except ValueError:
             flash('Invalid input!', 'error')
             return redirect(url_for('admin_manual_cycletest'))

    students = Student.query.order_by(Student.roll_number).all()
    return render_template('admin_manual_cycletest.html', students=students)


@app.route('/admin/manual/revision', methods=['GET', 'POST'])
@login_required
def admin_manual_revision():
    if current_user.role != 'admin':
        return redirect(url_for('dashboard'))
    
    if request.method == 'POST':
        subject = request.form.get('subject')
        test_number = request.form.get('test_number')
        max_marks = request.form.get('max_marks')
        test_date_str = request.form.get('test_date')
        
        if not subject or not test_number:
            flash('Subject and Test Number are required!', 'error')
            return redirect(url_for('admin_manual_revision'))
            
        try:
            test_date = datetime.strptime(test_date_str, '%Y-%m-%d').date() if test_date_str else datetime.utcnow().date()
            
            students = Student.query.all()
            count = 0
            
            for student in students:
                marks_key = f"marks_{student.id}"
                marks = request.form.get(marks_key)
                
                if marks:
                    if marks == "": continue
                    
                    existing = Revision.query.filter_by(
                        student_id=student.id,
                        subject=subject,
                        test_number=int(test_number)
                    ).first()
                    
                    if existing:
                        existing.marks = int(marks)
                        existing.max_marks = int(max_marks)
                        existing.test_date = test_date
                    else:
                        new_rev = Revision(
                            student_id=student.id,
                            subject=subject,
                            test_number=int(test_number),
                            marks=int(marks),
                            max_marks=int(max_marks),
                            test_date=test_date
                        )
                        db.session.add(new_rev)
                    count += 1
            
            db.session.commit()
            flash(f'✅ Revision marks entered for {count} students successfully!', 'success')
            return redirect(url_for('admin_upload'))
            
        except ValueError:
             flash('Invalid input!', 'error')
             return redirect(url_for('admin_manual_revision'))

    students = Student.query.order_by(Student.roll_number).all()
    return render_template('admin_manual_revision.html', students=students)


@app.route('/admin/manual/practical', methods=['GET', 'POST'])
@login_required
def admin_manual_practical():
    if current_user.role != 'admin':
        return redirect(url_for('dashboard'))
    
    if request.method == 'POST':
        subject = request.form.get('subject')
        title = request.form.get('title')
        max_marks = request.form.get('max_marks')
        date_str = request.form.get('completion_date')
        
        if not subject or not title:
            flash('Subject and Title are required!', 'error')
            return redirect(url_for('admin_manual_practical'))
            
        try:
            completion_date = datetime.strptime(date_str, '%Y-%m-%d').date() if date_str else None
            
            students = Student.query.all()
            count = 0
            
            for student in students:
                marks_key = f"marks_{student.id}"
                status_key = f"status_{student.id}"
                
                marks = request.form.get(marks_key)
                status = request.form.get(status_key)
                
                if marks or status:
                    # Logic: Identify practical by subject + title for this student
                    existing = Practical.query.filter_by(
                        student_id=student.id,
                        subject=subject,
                        title=title
                    ).first()
                    
                    marks_val = int(marks) if marks else 0
                    
                    if existing:
                        existing.marks = marks_val
                        existing.max_marks = int(max_marks)
                        existing.status = status
                        if completion_date:
                            existing.completion_date = completion_date
                    else:
                        new_prac = Practical(
                            student_id=student.id,
                            subject=subject,
                            title=title,
                            marks=marks_val,
                            max_marks=int(max_marks),
                            status=status,
                            completion_date=completion_date
                        )
                        db.session.add(new_prac)
                    count += 1
            
            db.session.commit()
            flash(f'✅ Practical records updated for {count} students successfully!', 'success')
            return redirect(url_for('admin_upload'))
            
        except ValueError:
             flash('Invalid input!', 'error')
             return redirect(url_for('admin_manual_practical'))

    students = Student.query.order_by(Student.roll_number).all()
    students = Student.query.order_by(Student.roll_number).all()
    return render_template('admin_manual_practical.html', students=students)


@app.route('/admin/announcements', methods=['GET', 'POST'])
@login_required
def admin_announcements():
    if current_user.role != 'admin':
        return redirect(url_for('dashboard'))
    
    if request.method == 'POST':
        title = request.form.get('title')
        content = request.form.get('content')
        
        if not title or not content:
            flash('Title and Content are required!', 'error')
        else:
            new_announcement = Announcement(
                title=title,
                content=content,
                date_posted=datetime.utcnow()
            )
            db.session.add(new_announcement)
            db.session.commit()
            flash('✅ Announcement posted successfully!', 'success')
            return redirect(url_for('admin_announcements'))
            
    # Get all announcements, newest first
    announcements = Announcement.query.order_by(Announcement.date_posted.desc()).all()
    return render_template('admin_announcements.html', announcements=announcements)


@app.route('/admin/announcement/delete/<int:id>', methods=['POST'])
@login_required
def admin_delete_announcement(id):
    if current_user.role != 'admin':
        return redirect(url_for('dashboard'))
        
    announcement = Announcement.query.get_or_404(id)
    db.session.delete(announcement)
    db.session.commit()
    flash('✅ Announcement deleted!', 'success')
    return redirect(url_for('admin_announcements'))



# ---------------------------------
# RUN
# ---------------------------------
if __name__ == '__main__':
    app.run(debug=True)

