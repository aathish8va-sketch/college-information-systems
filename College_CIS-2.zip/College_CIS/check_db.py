from app import app, db, Student, User

with app.app_context():
    student = Student.query.filter_by(roll_number='TST999').first()
    if student:
        print(f"Found student: {student.name}, {student.department}")
        user = User.query.filter_by(username='TST999').first()
        if user:
            print(f"Found user: {user.username}")
        else:
            print("User not found.")
            
        # Delete them to clean up
        db.session.delete(student)
        db.session.commit()
        print("Test data cleaned up.")
    else:
        print("Student not found. Let's add them directly to verify model logic.")
        try:
            new_student = Student(
                name="Direct Test",
                roll_number="DT999",
                email="dt@test.com",
                phone="12345",
                department="IT",
                semester=1
            )
            db.session.add(new_student)
            db.session.flush()
            new_user = User(username="DT999", role="student", student_id=new_student.id)
            new_user.set_password("pass")
            db.session.add(new_user)
            db.session.commit()
            print("Direct add successful.")
            
            # Clean up
            db.session.delete(new_student)
            db.session.commit()
            print("Clean up successful.")
        except Exception as e:
            print(f"Direct error: {e}")
