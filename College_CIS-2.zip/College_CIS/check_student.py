from app import app, db
from models import User
import json

with app.app_context():
    username = "vishalachi"
    user = User.query.filter_by(username=username).first()
    
    if user and user.student:
        data = {
            "username": user.username,
            "student_id": user.student.id,
            "name": user.student.name,
            "roll": user.student.roll_number,
            "dept": user.student.department,
            "sem": user.student.semester
        }
        print(json.dumps(data, indent=2))
    else:
        print(json.dumps({"error": "User or Student not found"}))
