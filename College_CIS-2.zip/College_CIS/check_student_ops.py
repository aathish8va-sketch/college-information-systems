import urllib.request
import urllib.parse
import json
import re

login_url = "http://localhost:5000/login"

data = urllib.parse.urlencode({"username": "admin", "password": "adminpassword", "login": "true"}).encode('ascii')

req = urllib.request.Request(login_url, data=data)
response = urllib.request.urlopen(req)

# Get cookie
cookie = response.headers.get('Set-Cookie')

# Add Student
add_url = "http://localhost:5000/admin/student/add"
student_data = urllib.parse.urlencode({
    "name": "Test Student",
    "roll_number": "TST999",
    "email": "test@college.edu",
    "phone": "9998887776",
    "department": "CSE",
    "semester": "5"
}).encode('ascii')

req = urllib.request.Request(add_url, data=student_data)
req.add_header('Cookie', cookie)
response = urllib.request.urlopen(req)
print("Add Student response status:", response.status)

# Check students page
req = urllib.request.Request("http://localhost:5000/admin/students")
req.add_header('Cookie', cookie)
response = urllib.request.urlopen(req)
html = response.read().decode('utf-8')

if "TST999" in html:
    print("Test Student added successfully.")
else:
    print("Test Student not found.")

match = re.search(r"openEditModal\((\d+),.*TST999", html)
if match:
    student_id = match.group(1)
    print("Found student ID:", student_id)
    
    del_url = f"http://localhost:5000/admin/student/{student_id}/delete"
    req = urllib.request.Request(del_url, data=b"") # POST request
    req.add_header('Cookie', cookie)
    response = urllib.request.urlopen(req)
    print("Delete student response status:", response.status)
    
    req = urllib.request.Request("http://localhost:5000/admin/students")
    req.add_header('Cookie', cookie)
    response = urllib.request.urlopen(req)
    html = response.read().decode('utf-8')
    if "TST999" not in html:
        print("Student successfully deleted.")
    else:
        print("Student deletion failed.")
else:
    print("Could not find student ID for deletion test.")
