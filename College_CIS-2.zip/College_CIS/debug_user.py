from app import app, db
from models import User, Student

with app.app_context():
    username = "vishalachi"
    user = User.query.filter_by(username=username).first()
    
    if not user:
        print(f"❌ User '{username}' does not exist.")
    else:
        print(f"✅ User found: ID={user.id}, Role={user.role}")
        
        if user.role == 'student':
            if user.student:
                print(f"✅ Linked Student Record: ID={user.student.id}, Name={user.student.name}, Roll={user.student.roll_number}")
            else:
                print("❌ ERROR: User has 'student' role but NO linked Student record!")
        
        # Reset password to '123' just in case
        print("Resetting password to '123'...")
        user.set_password("123")
        db.session.commit()
        print("✅ Password reset to '123'")
