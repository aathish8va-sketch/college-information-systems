from app import app, db
from models import User

with app.app_context():
    users = User.query.all()
    with open("creds.txt", "w") as f:
        for user in users:
            f.write(f"User: {user.username}, Role: {user.role}\n")
