from app import app, db, Result, Attendance, CycleTest

with app.app_context():
    print("--- Results Subjects ---")
    results = db.session.query(Result.subject).distinct().all()
    for r in results:
        print(r[0])

    print("\n--- Attendance Subjects ---")
    att = db.session.query(Attendance.subject).distinct().all()
    for a in att:
        print(a[0])

    print("\n--- CycleTest Subjects ---")
    cts = db.session.query(CycleTest.subject).distinct().all()
    for ct in cts:
        print(ct[0])
