from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash

db = SQLAlchemy()


class User(UserMixin, db.Model):
    """User authentication model"""
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(200), nullable=False)
    role = db.Column(db.String(20), default='student')  # student, admin
    student_id = db.Column(db.Integer, db.ForeignKey('student.id'), nullable=True)
    
    student = db.relationship('Student', backref=db.backref('user', uselist=False, cascade='all, delete-orphan'))
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)


class Student(db.Model):
    """Student information model"""
    id = db.Column(db.Integer, primary_key=True)
    roll_number = db.Column(db.String(20), unique=True, nullable=False)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100))
    phone = db.Column(db.String(15))
    department = db.Column(db.String(50))
    semester = db.Column(db.Integer)
    profile_picture = db.Column(db.String(200), default='default.png')
    
    # Relationships
    attendance_records = db.relationship('Attendance', backref='student', lazy=True, cascade='all, delete-orphan')
    results = db.relationship('Result', backref='student', lazy=True, cascade='all, delete-orphan')
    homework_records = db.relationship('Homework', backref='student', lazy=True, cascade='all, delete-orphan')
    cycletest_records = db.relationship('CycleTest', backref='student', lazy=True, cascade='all, delete-orphan')
    competition_records = db.relationship('Competition', backref='student', lazy=True, cascade='all, delete-orphan')
    revision_records = db.relationship('Revision', backref='student', lazy=True, cascade='all, delete-orphan')
    practical_records = db.relationship('Practical', backref='student', lazy=True, cascade='all, delete-orphan')


class Attendance(db.Model):
    """Attendance tracking model"""
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey('student.id'), nullable=False)
    date = db.Column(db.Date, nullable=False)
    subject = db.Column(db.String(50))
    status = db.Column(db.String(10))  # Present, Absent, Leave
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class Result(db.Model):
    """Exam results model"""
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey('student.id'), nullable=False)
    subject = db.Column(db.String(50), nullable=False)
    marks = db.Column(db.Integer, nullable=False)
    max_marks = db.Column(db.Integer, default=100)
    exam_type = db.Column(db.String(30))  # Semester, Final
    semester = db.Column(db.Integer)
    exam_date = db.Column(db.Date)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class Homework(db.Model):
    """Homework assignments model"""
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey('student.id'), nullable=False)
    subject = db.Column(db.String(50), nullable=False)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text)
    due_date = db.Column(db.Date)
    status = db.Column(db.String(20), default='Pending')  # Pending, Completed
    submission_date = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class Timetable(db.Model):
    """Class timetable model"""
    id = db.Column(db.Integer, primary_key=True)
    day = db.Column(db.String(10), nullable=False)  # Monday, Tuesday, etc.
    period = db.Column(db.Integer, nullable=False)
    subject = db.Column(db.String(50), nullable=False)
    teacher = db.Column(db.String(100))
    room = db.Column(db.String(20))
    start_time = db.Column(db.Time)
    end_time = db.Column(db.Time)
    semester = db.Column(db.Integer)


class CycleTest(db.Model):
    """Cycle test marks model"""
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey('student.id'), nullable=False)
    subject = db.Column(db.String(50), nullable=False)
    cycle_number = db.Column(db.Integer, nullable=False)  # 1, 2, 3
    marks = db.Column(db.Integer, nullable=False)
    max_marks = db.Column(db.Integer, default=50)
    test_date = db.Column(db.Date)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class Competition(db.Model):
    """Competitions and events model"""
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey('student.id'), nullable=True)
    name = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text)
    event_date = db.Column(db.Date)
    category = db.Column(db.String(50))  # Technical, Cultural, Sports
    position = db.Column(db.String(20))  # Winner, Runner-up, Participant
    certificate = db.Column(db.String(200))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class Revision(db.Model):
    """Revision test marks model"""
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey('student.id'), nullable=False)
    subject = db.Column(db.String(50), nullable=False)
    test_number = db.Column(db.Integer, nullable=False)  # 1, 2, 3...
    marks = db.Column(db.Integer, nullable=False)
    max_marks = db.Column(db.Integer, default=50)
    test_date = db.Column(db.Date)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class Practical(db.Model):
    """Practical records model"""
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey('student.id'), nullable=False)
    subject = db.Column(db.String(50), nullable=False)
    title = db.Column(db.String(200), nullable=False) # Title of experiment/practical
    marks = db.Column(db.Integer, nullable=False)
    max_marks = db.Column(db.Integer, default=100)
    status = db.Column(db.String(20), default='Completed') # Completed, Pending
    completion_date = db.Column(db.Date)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class Announcement(db.Model):
    """Announcement model"""
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    content = db.Column(db.Text, nullable=False)
    date_posted = db.Column(db.DateTime, default=datetime.utcnow)
