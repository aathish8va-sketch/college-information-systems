from app import app, db
from models import Student, Revision, Practical
from datetime import date

with app.app_context():
    print("Seeding data...")
    student = Student.query.first()
    if not student:
        print("No students found. Creating a dummy student.")
        student = Student(roll_number='CS001', name='John Doe', department='CSE', semester=5)
        db.session.add(student)
        db.session.commit()

    # Clear existing revision/practical data to avoid duplicates/confusion
    Revision.query.filter_by(student_id=student.id).delete()
    Practical.query.filter_by(student_id=student.id).delete()
    
    # Revision Data with CORRECT SUBJECTS
    revisions = [
        Revision(student_id=student.id, subject='Multimedia System', test_number=1, marks=45, max_marks=50, test_date=date(2023, 10, 1)),
        Revision(student_id=student.id, subject='Computer Hardware and Networking', test_number=1, marks=42, max_marks=50, test_date=date(2023, 10, 2)),
        Revision(student_id=student.id, subject='Cloud Computing', test_number=1, marks=48, max_marks=50, test_date=date(2023, 10, 3)),
        Revision(student_id=student.id, subject='AI', test_number=1, marks=40, max_marks=50, test_date=date(2023, 10, 4)),
    ]
    
    # Practical Data with CORRECT SUBJECTS
    practicals = [
        Practical(student_id=student.id, subject='AI', title='Linear Regression', marks=95, status='Completed', completion_date=date(2023, 9, 15)),
        Practical(student_id=student.id, subject='Cloud Computing', title='AWS Setup', marks=90, status='Completed', completion_date=date(2023, 9, 20)),
        Practical(student_id=student.id, subject='Multimedia System', title='Image Compression', marks=88, status='Completed', completion_date=date(2023, 9, 25)),
    ]
    
    db.session.add_all(revisions)
    db.session.add_all(practicals)
    db.session.commit()
    print("Seeded Revision and Practical data with correct subjects.")
