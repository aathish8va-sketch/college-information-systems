from app import app, db, User

def test():
    with app.test_client() as client:
        # Login
        resp = client.post('/login', data={'userid': 'admin', 'password': 'adminpassword'})
        print("Login redrect status:", resp.status_code)
        
        # Get admin students
        resp = client.get('/admin/students')
        print("Admin students status:", resp.status_code)
        if resp.status_code == 500:
            print("Server error rendering admin_students.html")
            print(resp.data.decode('utf-8')[:500])
        else:
            html = resp.data.decode('utf-8')
            print("Rendered OK. Length:", len(html))
            if "vishalachi" in html:
                print("vishalachi is in the HTML")
                
if __name__ == '__main__':
    test()
