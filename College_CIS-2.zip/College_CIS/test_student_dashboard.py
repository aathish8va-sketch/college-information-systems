from app import app, db, User, Student
from datetime import datetime

with app.app_context():
    # clean up previous if exists
    existing = User.query.filter_by(username='teststudentlogin').first()
    if existing:
        if existing.student:
            db.session.delete(existing.student)
        db.session.delete(existing)
        db.session.commit()

    student = Student(
        name='Test Student Login',
        roll_number='TEST001',
        email='test@email.com',
        phone='123456',
        department='CSE',
        semester=1
    )
    db.session.add(student)
    db.session.flush()

    user = User(username='teststudentlogin', role='student', student_id=student.id)
    user.set_password('pass123')
    db.session.add(user)
    db.session.commit()
    print("Test student created.")

with app.test_client() as client:
    # Login
    resp = client.post('/login', data={'userid': 'teststudentlogin', 'password': 'pass123'})
    print("Login response status:", resp.status_code)
    
    # Get dashboard
    resp = client.get('/dashboard')
    print("Dashboard response status:", resp.status_code)
    if resp.status_code == 500:
        print("Dashboard crashed!")
        print(resp.data.decode('utf-8')[:1000])
    
    # Also check profile or other pages that might be accessed
    resp = client.get('/profile')
    print("Profile response status:", resp.status_code)
    if resp.status_code == 500:
        print(resp.data.decode('utf-8')[:1000])
